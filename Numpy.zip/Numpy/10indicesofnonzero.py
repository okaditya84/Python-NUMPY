#find indices of non-zero elements
import numpy as np
x = np.array([1,2,0,0,4,0])
print(x)
print("The indices of non-zero elements are:")
for i in range(len(x)):
    if x[i] != 0:
        print(i)
        