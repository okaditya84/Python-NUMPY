#create a 10x10 array of integers and find the minimum and maximum element
import numpy as np
x = np.random.randint(0,100,(10,10))

print(x)
print("The minimum element is:")
print(x.min())
print("The maxijum element is:")
print(x.max())