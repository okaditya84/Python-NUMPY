#Create a null vector of size 10
import numpy as np
x = np.zeros(10)
print(x)
#Create a null vector of size 10 but the fifth value which is 1
x[4] = 1
print(x)

