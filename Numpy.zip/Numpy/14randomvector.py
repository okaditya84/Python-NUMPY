#create a random vector of integers of size 30 and find the mean value
import numpy as n
x = n.random.randint(0,100,30)
print(x)
print("The mean value is:")
print(x.mean())
