#create a vector ranging from 10 to 49
import numpy as np
x = np.arange(10,50)
print(x)
