#find the memory size of an array in numpy
import numpy as npp
#make a simple array
a = npp.array([1,2,3,4,5])
print(a)
#find the memory size 

print(a.nbytes)