#create a 3x# identity matrix
import numpy as n
x = n.identity(3)
print(x)
