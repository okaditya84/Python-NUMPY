#add zeroes to the border of any user given array
import numpy as n
#take 2 d array import

x = n.array([[1,2,3],[4,5,6],[7,8,9]])
print(x)
print("The 2D array with 0 on the border is:")
#add zeroes to the border of the array
x = n.pad(x, pad_width=1, mode='constant', constant_values=0)
print(x)