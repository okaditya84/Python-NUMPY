#create a 3X3 matrix with values ranging from 0 to 8
import numpy as n
x = n.arange(0,9)
print(x)
print("The 3X3 matrix is:")
print(x.reshape(3,3))
