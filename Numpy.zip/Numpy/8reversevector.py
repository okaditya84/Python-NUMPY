#reverse a vector
import numpy as np
x = np.arange(10,50)
print(x)
print("The reverse of the vector is:")
print(x[::-1])
